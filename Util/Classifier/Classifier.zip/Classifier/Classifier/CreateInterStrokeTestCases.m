% For wlo_other dmax = 15; tmax = 35;
% For wlo_label 
dmax = 5;
tmax = 100;
dlim = dmax / 25.4 * 2800 / 10000;
tlim = tmax / 110;
num = 101;
d = linspace(0,dlim,num); 
t = linspace(0,tlim,num);
fid = fopen('C:\\Documents and Settings\\eric\\My Documents\\SVN Repository\\Util\\Classifier\\Classifier\\surface.txt','w');
for i = 1:length(d)
    for j = 1:length(t)
        fprintf(fid, '%6.4f %6.4f\n', d(i), t(j)); 
    end
end
fclose('all');