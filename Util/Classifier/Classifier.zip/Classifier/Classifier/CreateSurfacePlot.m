clear all;
close all;
clc;

% For wlo_other dmax = 15; tmax = 35;
% For wlo_label 
dmax = 5;
tmax = 100;
dlim = dmax / 25.4 * 2800 / 10000;
tlim = tmax / 110;
num = 101;

fid = fopen('C:\\Documents and Settings\\eric\\My Documents\\SVN Repository\\Util\\Classifier\\Classifier\\surfaceValues.txt','r');

C = textscan(fid, '%f %f %f');
fclose(fid);
fclose('all');
f = C{3};

d = linspace(0,dlim,num);
x = d * 10000 / 2800 * 25.4;
t = linspace(0,tlim,num);
y = t * 110;
[X,Y] = meshgrid(x,y);

Z = zeros(num,num);
n = 0;
for i = 1:num
    for j = 1:num
        n = n + 1;
        Z(i,j) = f(n); 
    end
end

surface(X,Y,Z);
ylabel('Distance (mm)');
xlabel('Time Gap (seconds)');
zlabel('Neural Net Output');
title('Likelihood of grouping Strokes');
view(130,45);
grid on;